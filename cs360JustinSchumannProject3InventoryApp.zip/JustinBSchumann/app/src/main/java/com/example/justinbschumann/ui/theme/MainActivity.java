package com.example.justinbschumann.ui.theme;

import static com.example.justinbschumann.R.*;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.justinbschumann.R;

public class MainActivity extends AppCompatActivity {
    EditText nameText;
    TextView textView;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main2);
        final Button buttonSayHello = (Button) findViewById(R.id.buttonSayHello);
        EditText nameText = (EditText) findViewById(R.id.nameText);

        nameText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                buttonSayHello.setEnabled(!s.toString().isEmpty());
            }

            @Override
            public void afterTextChanged(Editable s) {}

        });


    }
    public void SayHello(View view) {
        EditText nameText = (EditText) findViewById(R.id.nameText);
        TextView textGreeting = (TextView) findViewById(R.id.textGreeting);

        if (nameText.getText().toString().trim().length() > 0) {
            textGreeting.setText("Hello " + nameText.getText().toString());
        } else {
            textGreeting.setText("You must enter a name");
        }
    }
}